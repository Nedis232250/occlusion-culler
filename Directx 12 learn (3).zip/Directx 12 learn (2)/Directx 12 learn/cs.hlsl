


[numthreads(1024, 1, 1)]
void main(uint3 threadID : SV_DispatchThreadID, uint3 groupID : SV_GroupThreadID, uint3 group_num : SV_GroupID) {
}