StructuredBuffer<float> vertices : register(t0);

struct VSOutput {
    float4 position : SV_POSITION;
    float4 color : COLOR0;
};

VSOutput main(uint vertexID : SV_VertexID) {
    uint starting_index = vertexID * 7;
    VSOutput output;
    
    half3 coordinates = half3(vertices[starting_index], vertices[starting_index + 1], vertices[starting_index + 2]);
    
    output.position = float4(coordinates, (coordinates.z + 0.01h));
    output.position.z *= 0.01h;
    output.color = float4(vertices[starting_index + 3], vertices[starting_index + 4], vertices[starting_index + 5], vertices[starting_index + 6]);
    return output;
}