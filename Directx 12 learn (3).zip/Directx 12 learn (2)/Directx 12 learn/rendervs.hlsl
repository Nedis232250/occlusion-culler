StructuredBuffer<float> vertices : register(t0);
ByteAddressBuffer triangles : register(t1);
StructuredBuffer<uint> cull_buffer : register(t2);

struct VSOutput {
    float4 position : SV_POSITION;
    float4 color : COLOR0;
};

VSOutput main(uint vertexID : SV_VertexID) {
    VSOutput output;
    if ((triangles.Load(4 * (vertexID / 3)) == 0 && cull_buffer[vertexID / 3] == 1) || cull_buffer[vertexID / 3] == 2) {
        output.position = float4(0.0f, 0.0f, 0.0f, 0.0f);
        output.color = float4(0.0f, 0.0f, 0.0f, 1.0f);
        return output;
    }
    
    uint starting_index = vertexID * 7;
    
    half3 coordinates = half3(vertices[starting_index], vertices[starting_index + 1], vertices[starting_index + 2]);
    
    output.position = float4(coordinates, (coordinates.z + 0.01h));
    output.position.z *= 0.01h;
    output.color = float4(vertices[starting_index + 3], vertices[starting_index + 4], vertices[starting_index + 5], vertices[starting_index + 6]);
    return output;
}